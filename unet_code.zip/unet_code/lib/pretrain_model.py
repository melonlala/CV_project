import torch
import segmentation_models_pytorch as smp

def Pretrained_UNet(out_ch=4):
    model = smp.Unet(
        encoder_name='efficientnet-b1', # choose encoder, e.g. mobilenet_v2 or efficientnet-b7
        encoder_weights="imagenet",     # use `imagenet` pre-trained weights for encoder initialization
        in_channels=3,                  # model input channels (1 for gray-scale images, 3 for RGB, etc.)
        classes=out_ch,                 # model output channels (number of classes in your dataset)
    )
    return model

